package com.example.messagingrabbitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessagingRabbitmqApplicationTests {

	@Test
	void contextLoads() {
	}

}
